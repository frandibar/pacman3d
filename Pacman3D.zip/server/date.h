#ifndef __DATE_H__
#define __DATE_H__
#include <string>
using std::string;

/**
 * Clase que obtiene un timestamp de la hora y fecha actual
 * 
 * */
class Date {
  public:
  	/**
  	 * devuelve fecha y hora del instante en q se invoca en forma de string
  	 * yyyy-mm-dd hh:mm:ss
  	 */
    static string now();
};
#endif /* __DATE_H__ */
