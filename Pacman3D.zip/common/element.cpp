#include "element.h"

const unsigned short Element::ratio = 4;
