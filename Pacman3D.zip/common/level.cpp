//definicion de metodos de clase Level
#include "common/level.h"

Level::Level(PacManMap * pacManMap, tLevelSpeed speed) {
  _map = pacManMap;
  _speed = speed;
}

Level::~Level() {
	// Analizar si realmente tenemos que hacer delete aqui !!
  // delete _map;
}
