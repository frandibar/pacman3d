//main del cliente
#include "editor/editorscreen.h"
//constantes de retorno
#define END 0

int main(int argc, char **argv) {
  //muestra pantalla de editor
  EditorScreen screen(argc,argv);
  return END;
}
