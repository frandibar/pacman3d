//main del server
#include "server/server.h"

int main(int argc, char **argv) {
  Server server(argc,argv);
  return server.run();
}
